var searchData=
[
  ['setcolor_0',['SetColor',['../class_door.html#a0e8ce0b7f3f1d283c277a74b281a2b13',1,'Door']]]
];
